local attackAnimations = { 'attackLEFT', 'attackDOWN', 'attackUP', 'attackRIGHT' }
local dodgeAnimations = { 'dodgeLEFT', 'dodgeDOWN', 'dodgeUP', 'dodgeRIGHT' }
local lastBulletSoundTime = -1

function onCreate()
	precacheImage('BULLETNOTE_assets', true)
	precacheSound('bulletNoteHit')
end

function onCreatePost()
	for i = 0, getProperty('unspawnNotes.length') - 1 do
		if getPropertyFromGroup('unspawnNotes', i, 'noteType') == 'Bullet Note' then
			setPropertyFromGroup('unspawnNotes', i, 'texture', 'BULLETNOTE_assets')
			setPropertyFromGroup('unspawnNotes', i, 'missHealth', 0.6)

			if getPropertyFromGroup('unspawnNotes', i, 'mustPress') then
				setPropertyFromGroup('unspawnNotes', i, 'ignoreNote', false)
			end
		end
	end
end

function goodNoteHit(id, noteData, noteType, isSustainNote)
	if noteType == 'Bullet Note' then
		playAnim('boyfriend', dodgeAnimations[noteData + 1], true)
		setProperty('boyfriend.specialAnim', true)

		playAnim('dad', attackAnimations[noteData + 1], true)
		setProperty('dad.specialAnim', true)

		local strumTime = getPropertyFromGroup('notes', id, 'strumTime')
		if strumTime ~= lastBulletSoundTime then
			playSound('bulletNoteHit', 0.33)
			lastBulletSoundTime = strumTime
		end
		cameraShake('game', 0.01, 0.1)
	end
end

function noteMiss(id, noteData, noteType, isSustainNote)
	if noteType == 'Bullet Note' then
		playAnim('dad', attackAnimations[noteData + 1], true)
		setProperty('dad.specialAnim', true)

		playAnim('boyfriend', 'hurt', true)
		setProperty('boyfriend.specialAnim', true)

		local strumTime = getPropertyFromGroup('notes', id, 'strumTime')
		if strumTime ~= lastBulletSoundTime then
			playSound('bulletNoteHit', 0.33)
			lastBulletSoundTime = strumTime
		end
		cameraShake('game', 0.02, 0.2)
	end
end
