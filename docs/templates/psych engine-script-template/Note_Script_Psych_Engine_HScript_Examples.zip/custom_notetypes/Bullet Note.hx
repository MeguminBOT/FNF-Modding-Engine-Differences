var attackAnimations = [ 'attackLEFT', 'attackDOWN', 'attackUP', 'attackRIGHT' ];
var dodgeAnimations = [ 'dodgeLEFT', 'dodgeDOWN', 'dodgeUP', 'dodgeRIGHT' ];

var _cachedImages = new haxe.ds.StringMap();
var _cachedSounds = new haxe.ds.StringMap();
var lastBulletSoundTime:Float = -1;

function onCreate() {
	_cachedImages.set('BULLETNOTE_assets', Paths.image('BULLETNOTE_assets'));
	_cachedSounds.set('bulletNoteHit', Paths.sound('bulletNoteHit'));
}

function onCreatePost() {
	for (i in 0...game.unspawnNotes.length) {
		if (game.unspawnNotes[i].noteType == 'Bullet Note') {
			game.unspawnNotes[i].texture = 'BULLETNOTE_assets';
			game.unspawnNotes[i].missHealth = 0.63;

			if (game.unspawnNotes[i].mustPress) {
				game.unspawnNotes[i].ignoreNote = false;
			}
		}
	}
}

function goodNoteHit(note:Note) {
	if (note.noteType == 'Bullet Note') {
		game.boyfriend.playAnim(dodgeAnimations[note.noteData], true);
		game.boyfriend.specialAnim = true;

		game.dad.playAnim(attackAnimations[note.noteData], true);
		game.dad.specialAnim = true;

		if (note.strumTime != lastBulletSoundTime) {
			FlxG.sound.play(Paths.sound('bulletNoteHit'), 0.5);
			lastBulletSoundTime = note.strumTime;
		}
		game.camGame.shake(0.01, 0.1);
	}
}

function noteMiss(note:Note) {
	if (note.noteType == 'Bullet Note') {
		game.dad.playAnim(attackAnimations[note.noteData], true);
		game.dad.specialAnim = true;

		game.boyfriend.playAnim('hurt', true);
		game.boyfriend.specialAnim = true;

		if (note.strumTime != lastBulletSoundTime) {
			FlxG.sound.play(Paths.sound('bulletNoteHit'), 0.5);
			lastBulletSoundTime = note.strumTime;
		}
		game.camGame.shake(0.02, 0.2);
	}
}

function onDestroy() {
	_cachedImages.clear();
	_cachedSounds.clear();
}