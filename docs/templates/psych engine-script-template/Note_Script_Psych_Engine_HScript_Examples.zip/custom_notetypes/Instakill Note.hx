function onCreatePost() {
	for (i in 0...game.unspawnNotes.length) {
		if (game.unspawnNotes[i].noteType == 'Instakill Note') {
			game.unspawnNotes[i].texture = 'INSTAKILLNOTE_assets';

			if (game.unspawnNotes[i].mustPress) {
				game.unspawnNotes[i].ignoreNote = true;
			}
		}
	}
}

function goodNoteHit(note:Note) {
	if (note.noteType == 'Instakill Note') {
		game.health = -3;
	}
}

function noteMiss(note:Note) {
	if (note.noteType == 'Instakill Note') {

	}
}